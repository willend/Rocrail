/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr  4 2016 14:44:20)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: System
  * Date: Mon Apr  4 14:47:06 2016
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/system_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOSystemData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OSystem ----- */


/** check device access */
static Boolean _accessDev( const char* device ,Boolean readonly ) {
  return 0;
}


/** try to get port access */
static Boolean _accessPort( int from ,int num ) {
  return 0;
}


/** available from device */
static int _availDevice( long handle ) {
  return 0;
}


/** Beeps. */
static void _beep( void ) {
  return;
}


/** Translates Windows CP1252 into Latin 15. */
static char* _cp1252toISO885915( const char* str ) {
  return 0;
}


/**  */
static char* _decode( const byte* b ,int len ,const char* k ) {
  return 0;
}


/** Get the Rocs build string. */
static const char* _getBuild( void ) {
  return 0;
}


/** Translates an error code into a string. */
static const char* _getErrStr( int error ) {
  return 0;
}


/**  */
static const char* _getEyecatcher( void ) {
  return 0;
}


/**  */
static char _getFileSeparator( void ) {
  return 0;
}


/** Get global unique ID. (32 chars long) */
static char* _getGUID( const char* macdev ) {
  return 0;
}


/**  */
static int _getMillis( void ) {
  return 0;
}


/**  */
static ostype _getOSType( void ) {
  return 0;
}


/**  */
static char _getPathSeparator( void ) {
  return 0;
}


/** Path separator for a specific OS type. */
static char _getPathSeparator4OS( ostype type ) {
  return 0;
}


/**  */
static const char* _getPrgExt( void ) {
  return 0;
}


/** Reads an environment variable. */
static const char* _getProperty( const char* key ) {
  return 0;
}


/** Translates an signal number into a string. */
static const char* _getSigStr( int sig ) {
  return 0;
}


/** System tick in 10ms. */
static unsigned long _getTick( void ) {
  return 0;
}


/** returns milliseconds */
static int _getTime( int* hours ,int* minutes ,int* seconds ) {
  return 0;
}


/** Translates a local path into a UNC. */
static char* _getUNC( const char* filepath ) {
  return 0;
}


/**  */
static const char* _getUnlimEyecatcher( void ) {
  return 0;
}


/** Login username. */
static const char* _getUserName( void ) {
  return 0;
}


/** Workstation name. */
static const char* _getWSName( void ) {
  return 0;
}


/** Process ID. */
static int _getpid( void ) {
  return 0;
}


/** Object creator. (Singleton) */
static struct OSystem* _inst( void ) {
  iOSystem __System = allocMem( sizeof( struct OSystem ) );
  iOSystemData data = allocMem( sizeof( struct OSystemData ) );
  MemOp.basecpy( __System, &SystemOp, 0, sizeof( struct OSystem ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __System;
}


/**  */
static Boolean _isExpired( const char* s ,char** expdate ,long* expdays ,int vmajor ,int vminor ) {
  return 0;
}


/**  */
static Boolean _isUnix( void ) {
  return 0;
}


/**  */
static Boolean _isWindows( void ) {
  return 0;
}


/** Translates Latin 15 into CP850. */
static char* _latin2cp850( const char* latinstr ) {
  return 0;
}


/** Translates Latin 15 into UTF-8. */
static char* _latin2utf( const char* latinstr ) {
  return 0;
}


/** open device access */
static long _openDevice( const char* device ) {
  return 0;
}


/** read from device */
static Boolean _readDevice( long handle ,char* buffer ,int size ) {
  return 0;
}


/** read a byte to the port */
static byte _readPort( int port ) {
  return 0;
}


/** release the port access */
static Boolean _releasePort( int from ,int num ) {
  return 0;
}


/**  */
static Boolean _setAdmin( void ) {
  return 0;
}


/** Starts a system command. */
static int _system( const char* cmd ,Boolean async ,Boolean minimized ) {
  return 0;
}


/**  */
static Boolean _uBusyWait( int us ) {
  return 0;
}


/**  */
static Boolean _usWait( int us ) {
  return 0;
}


/** Translates fitting UTF-8 encodings into Lantin 15. */
static char* _utf2latin( const char* utfstr ) {
  return 0;
}


/** read from device */
static Boolean _writeDevice( long handle ,char* buffer ,int size ) {
  return 0;
}


/** write a byte to the port */
static void _writePort( int port ,byte val ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/system.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
