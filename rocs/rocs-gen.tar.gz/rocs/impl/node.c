/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr  4 2016 14:44:20)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Node
  * Date: Mon Apr  4 14:47:06 2016
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/node_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iONodeData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- ONode ----- */


/** Add an attribute. */
static void _addAttr( struct ONode* inst ,iOAttr attr ) {
  return;
}


/** Add a child node. */
static void _addChild( struct ONode* inst ,struct ONode* child ) {
  return;
}


/** Search for an attribute with the given name. */
static iOAttr _findAttr( struct ONode* inst ,const char* attrname ) {
  return 0;
}


/** Find next node with the same name. */
static struct ONode* _findNextNode( struct ONode* inst ,struct ONode* node ) {
  return 0;
}


/** Search for a child node with the given name. */
static struct ONode* _findNode( struct ONode* inst ,const char* nodename ) {
  return 0;
}


/** Get an attribute by index. */
static iOAttr _getAttr( struct ONode* inst ,int idx ) {
  return 0;
}


/** Get the number of attributes. */
static int _getAttrCnt( struct ONode* inst ) {
  return 0;
}


/** Get an attribute value as boolean. */
static Boolean _getBool( struct ONode* inst ,const char* attrname ,Boolean defval ) {
  return 0;
}


/** Get an child node by index. */
static struct ONode* _getChild( struct ONode* inst ,int idx ) {
  return 0;
}


/** Get the number of child nodes. */
static int _getChildCnt( struct ONode* inst ) {
  return 0;
}


/** Get an attribute value as float. */
static double _getFloat( struct ONode* inst ,const char* attrname ,double defval ) {
  return 0;
}


/** Get an attribute value as integer. */
static int _getInt( struct ONode* inst ,const char* attrname ,int defval ) {
  return 0;
}


/** Get an attribute value as long. */
static long _getLong( struct ONode* inst ,const char* attrname ,long defval ) {
  return 0;
}


/** Get the node name. */
static const char* _getName( struct ONode* inst ) {
  return 0;
}


/** Same as findNode but if no node is found it creates one. */
static struct ONode* _getNode( struct ONode* inst ,const char* nodename ) {
  return 0;
}


/** Get the parent node. */
static struct ONode* _getParent( struct ONode* inst ) {
  return 0;
}


/** Get an attribute value as string. */
static const char* _getStr( struct ONode* inst ,const char* attrname ,const char* defval ) {
  return 0;
}


/** Get the node type. */
static nodetype _getType( struct ONode* inst ) {
  return 0;
}


/** Object creator */
static struct ONode* _inst( const char* name ,struct ONode* parent ,nodetype type ) {
  iONode __Node = allocMem( sizeof( struct ONode ) );
  iONodeData data = allocMem( sizeof( struct ONodeData ) );
  MemOp.basecpy( __Node, &NodeOp, 0, sizeof( struct ONode ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Node;
}


/** Merge nodeB into A. */
static struct ONode* _mergeNode( struct ONode* nodeA ,struct ONode* nodeB ,Boolean overwrite ,Boolean recursive ,Boolean keepid ) {
  return 0;
}


/** Removes an attribute. */
static void _removeAttr( struct ONode* inst ,iOAttr attr ) {
  return;
}


/** Removes an attribute. */
static void _removeAttrByName( struct ONode* inst ,const char* name ) {
  return;
}


/** Remove a child node. */
static struct ONode* _removeChild( struct ONode* inst ,struct ONode* child ) {
  return 0;
}


/** Set an attribute value as boolean. */
static void _setBool( struct ONode* inst ,const char* attrname ,Boolean val ) {
  return;
}


/** Set an attribute value as float. */
static void _setFloat( struct ONode* inst ,const char* attrname ,double val ) {
  return;
}


/** Set an attribute value as integer. */
static void _setInt( struct ONode* inst ,const char* attrname ,int val ) {
  return;
}


/** Set an attribute value as long. */
static void _setLong( struct ONode* inst ,const char* attrname ,long val ) {
  return;
}


/** Set the node name. */
static void _setName( struct ONode* inst ,const char* name ) {
  return;
}


/** Change or set parent of this node. */
static void _setParent( struct ONode* inst ,struct ONode* parent ) {
  return;
}


/** Set an attribute value as string. */
static void _setStr( struct ONode* inst ,const char* attrname ,const char* val ) {
  return;
}


/** Set the node type. */
static void _setType( struct ONode* inst ,nodetype type ) {
  return;
}


/** Serialize this node with escaped attribute values. */
static char* _toEscString( struct ONode* inst ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/node.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
