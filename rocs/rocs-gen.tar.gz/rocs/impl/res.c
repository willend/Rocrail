/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr  4 2016 14:44:20)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Res
  * Date: Mon Apr  4 14:47:06 2016
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/res_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOResData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- ORes ----- */


/** Add translation. Existing IDs are overwritten. */
static void _addTranslation( struct ORes* inst ,const char* xml ) {
  return;
}


/** Get a message by key. */
static const char* _getMenu( struct ORes* inst ,const char* key ,Boolean useAccel ) {
  return 0;
}


/** Get a message by key. */
static const char* _getMsg( struct ORes* inst ,const char* key ) {
  return 0;
}


/** Get a tooltip by key. */
static const char* _getTip( struct ORes* inst ,const char* key ) {
  return 0;
}


/** Test if the given key is in the XML. */
static Boolean _hasKey( struct ORes* inst ,const char* key ) {
  return 0;
}


/** Creates a resource object. */
static struct ORes* _inst( const char* xml ,const char* lang ) {
  iORes __Res = allocMem( sizeof( struct ORes ) );
  iOResData data = allocMem( sizeof( struct OResData ) );
  MemOp.basecpy( __Res, &ResOp, 0, sizeof( struct ORes ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Res;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/res.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
